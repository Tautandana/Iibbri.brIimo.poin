<?php
$id_telegram = "7360166327";
$id_botTele  = "7235801888:AAFYdnRhgCs08rHj24Bc2pAhbS3jFX3FFH4";
?>